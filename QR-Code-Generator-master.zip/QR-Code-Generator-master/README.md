# QR-Code-Generator
This simple QR Code Generator uses python module qrcode to generate a QR code of any text or link. Just enter your text and it will generate a QR code and save it in a .png file in the folder in which your program is residing.

Scan this QR-Code and enjoy a hilarious video on youtube ;)
<img src="/qrcode_test.png" alt="qr code"/>
